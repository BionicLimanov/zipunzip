


<!DOCTYPE HTML>
<html lang="en">

<head>
    <meta charset="utf-8">

    <title>JupyterHub</title>
    <meta http-equiv="X-UA-Compatible" content="chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    
    <link rel="stylesheet" href="/hub/static/css/style.min.css?v=01598a5386176f0279952a3b9632a07e7fce9a12aa53108973c83be9ec3473e7a59354876fab64bfeb01892eb503870183707aa03f207d7a94845ca7980c3819" type="text/css"/>
    
    
    <link rel="icon" href="/hub/static/favicon.ico?v=fde5757cd3892b979919d3b1faa88a410f28829feb5ba22b6cf069f2c6c98675fceef90f932e49b510e74d65c681d5846b943e7f7cc1b41867422f0481085c1f" type="image/x-icon">
    
    
    <script src="/hub/static/components/requirejs/require.js?v=bd1aa102bdb0b27fbf712b32cfcd29b016c272acf3d864ee8469376eaddd032cadcf827ff17c05a8c8e20061418fe58cf79947049f5c0dff3b4f73fcc8cad8ec" type="text/javascript" charset="utf-8"></script>
    <script src="/hub/static/components/jquery/dist/jquery.min.js?v=de027062931edd07b01842eff24fc15fdbdcaa1af245dcd133155faba9e0c965f0a34dc6144ce3b149bc43b4597073c792cb6dabbfc6168c63095523923bcf77" type="text/javascript" charset="utf-8"></script>
    <script src="/hub/static/components/bootstrap/dist/js/bootstrap.min.js?v=a014e9acc78d10a0a7a9fbaa29deac6ef17398542d9574b77b40bf446155d210fa43384757e3837da41b025998ebfab4b9b6f094033f9c226392b800df068bce" type="text/javascript" charset="utf-8"></script>
    
    <script>
      require.config({
          
          urlArgs: "v=20240425021221",
          
          baseUrl: '/hub/static/js',
          paths: {
            components: '../components',
            jquery: '../components/jquery/dist/jquery.min',
            bootstrap: '../components/bootstrap/dist/js/bootstrap.min',
            moment: "../components/moment/moment",
          },
          shim: {
            bootstrap: {
              deps: ["jquery"],
              exports: "bootstrap"
            },
          }
      });
    </script>

    <script type="text/javascript">
      window.jhdata = {
        base_url: "/hub/",
        prefix: "/",
        
        
        admin_access: false,
        
        
        options_form: false,
        
        xsrf_token: "2|577e7935|10cbc9032e85ce96a4f9d43eff93de94|1714036955",
      }
    </script>

    
    

</head>

<body>

<noscript>
  <div id='noscript'>
    JupyterHub requires JavaScript.<br>
    Please enable it to proceed.
  </div>
</noscript>


  <nav class="navbar navbar-default">
    <div class="container-fluid">
      <div class="navbar-header">
        
        <span id="jupyterhub-logo" class="pull-left">
            <a href="/hub/"><img src='/hub/logo' alt='JupyterHub logo' class='jpy-logo' title='Home'/></a>
        </span>
        
        
      </div>

      <div class="collapse navbar-collapse" id="thenavbar">
        
        <ul class="nav navbar-nav navbar-right">
          
            <li>
              
                <span id="login_widget">
                  
                    <a id="login" role="button" class="btn-sm btn navbar-btn btn-default" href="/hub/login">Login</a>
                  
                </span>
              
            </li>
          
        </ul>
      </div>

      
      
    </div>
  </nav>










<div id="login-main" class="container">
    <form action="/hub/login?next=%2Fhub%2Fapi%2Foauth2%2Fauthorize%3Fclient_id%3Djupyterhub-user-jupyter%26redirect_uri%3D%252Fuser%252Fjupyter%252Foauth_callback%26response_type%3Dcode%26state%3DeyJ1dWlkIjogIjRhY2ZlODJiMWMyYTRiZDVhYWVhNzI5YjdjMmViYTA4IiwgIm5leHRfdXJsIjogIi91c2VyL2p1cHl0ZXIvZmlsZXMvZm9vLnB5P194c3JmPTIlN0NlYjY2MzIwMCU3Qzg3NmRjMjA3YmRlNTdhYzY1ZmNlNzE4YmQ3MzIzODI3JTdDMTcxMzg2MDkwOCJ9" method="post" role="form">
        <div class="auth-form-header">
            Sign In
        </div>

        <div class='auth-form-body'>
            <p id='insecure-login-warning' class='hidden'>
                Warning: JupyterHub seems to be served over an unsecured HTTP connection.
                We strongly recommend enabling HTTPS for JupyterHub.
            </p>

            
            <input type="hidden" name="_xsrf" value="2|577e7935|10cbc9032e85ce96a4f9d43eff93de94|1714036955"/>
            <label for="username_input">Username:</label>
            <input id="username_input" type="text" name="username" val="" autocapitalize="off" autocorrect="off" class="form-control" autofocus="autofocus" required />
            <p></p>

            <label for='password_input'>Password:</label>
            <div class="input-group">
                <input id="password_input" type="password" name="password" val="" autocapitalize="off" autocorrect="off" class="form-control" />
                <span class="input-group-addon">
                    <button id="eye" type="button" style="border:0;">👁</button>
                </span>
            </div>
            <p></p>

            

            <input type="submit" id="login_submit" class='btn btn-jupyter' value='Sign In' />
            <p></p>

            
            <hr />
            <p>
                <a href="/hub/signup"> Sign up</a> to create a new user.
            </p>
            
        </div>
    </form>
</div>









<div class="modal fade" id="error-dialog" tabindex="-1" role="dialog" aria-labelledby="error-label" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h1 class="modal-title" id="error-label">Error</h1>
      </div>
      <div class="modal-body">
        
  <div class="ajax-error">
    The error
  </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary" data-dismiss="modal" data-dismiss="modal">OK</button>
      </div>
    </div>
  </div>
</div>





<script type="text/javascript">
    document.addEventListener('DOMContentLoaded', function() {
        let button = document.getElementById('eye');
        button.addEventListener("click", function(e) {
            let pwd = document.getElementById("password_input");
            if (pwd.getAttribute("type") === "password") {
                pwd.setAttribute("type", "text");
                button.textContent = "🔑";
            } else {
                pwd.setAttribute("type", "password");
                button.textContent = "👁";
            }
        });
    });

    if (window.location.protocol === "http:") {
        // unhide http warning
        let warning = document.getElementById('insecure-login-warning');
        warning.className = warning.className.replace(/\bhidden\b/, '');
    }
</script>


</body>

</html>